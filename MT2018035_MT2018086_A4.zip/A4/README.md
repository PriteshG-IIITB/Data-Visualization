# DV-A4
Various visualization techniques for India Trade Dataset Kaggle.

The entire code starts at index.html. The application needs to run in a CORS enabled browser. Choropleth graphs are browser specific and hence if it doesn't work your version of Chrome, try running it on Firefox or IE.
